from django.apps import AppConfig


class BusketConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'busket'
